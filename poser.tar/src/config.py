from dataclasses import dataclass, field
import argparse

@dataclass(frozen=True)
class Config:
    camera: int = 0
    width: int = 1280
    height: int = 720
    mirror: bool = False
    face: bool = True
    body: bool = True
    hands: bool = True
    show_roi: bool = False
    show_fps: bool = False
    face_expressions: bool = False

def parse_args() -> Config:
    parser = argparse.ArgumentParser(description="Pose detection app configuration")
    parser.add_argument("--camera", type=int, default=0, help="Camera device index")
    parser.add_argument("--width", type=int, default=1280, help="Camera width")
    parser.add_argument("--height", type=int, default=720, help="Camera height")
    parser.add_argument("--mirror", action="store_true", help="Mirror the camera feed")
    parser.add_argument("--no-face", dest="face", action="store_false", help="Disable face detection")
    parser.add_argument("--no-body", dest="body", action="store_false", help="Disable body detection")
    parser.add_argument("--no-hands", dest="hands", action="store_false", help="Disable hands detection")
    parser.add_argument("--show-roi", action="store_true", help="Show region of interest")
    parser.add_argument("--fps", action="store_true", help="Show FPS")
    parser.add_argument("--face-expressions", action="store_true", help="Enable face expressions detection")
    parser.set_defaults(face=True, body=True, hands=True)
    args = parser.parse_args()
    return Config(
        camera=args.camera,
        width=args.width,
        height=args.height,
        mirror=args.mirror,
        face=args.face,
        body=args.body,
        hands=args.hands,
        show_roi=args.show_roi,
        show_fps=args.fps,
        face_expressions=args.face_expressions
    )
