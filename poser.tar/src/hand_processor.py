from __future__ import annotations
import numpy as np
from typing import List
from src.types import BoundingBox, Landmark, HandResult
from src.model_manager import ModelManager
from src.preprocessor import Preprocessor

class HandProcessor:
    """Hand pose detection processor using GPU-resident models."""

    DETECTOR_W = 192
    DETECTOR_H = 192
    LANDMARK_W = 224
    LANDMARK_H = 224
    CONF_THRESHOLD = 0.5
    NMS_IOU_THRESHOLD = 0.3
    MAX_HANDS = 2

    def __init__(self, model_manager: ModelManager):
        self.model_manager = model_manager
        self._anchors = self._generate_anchors()

    def _generate_anchors(self) -> np.ndarray:
        anchors = []
        g = 24  # grid size = 192 // 8
        for r in range(24):
            for c in range(24):
                for k in range(2):
                    cx = (c + 0.5) / g
                    cy = (r + 0.5) / g
                    anchors.append([cx, cy])
        g = 12  # grid size = 192 // 16
        for r in range(12):
            for c in range(12):
                for k in range(6):
                    cx = (c + 0.5) / g
                    cy = (r + 0.5) / g
                    anchors.append([cx, cy])
        return np.array(anchors, dtype=np.float32)

    def process(self, frame_gpu, frame_w: int, frame_h: int, mirror: bool) -> List[HandResult]:
        preprocessed = Preprocessor.full_frame_nhwc(frame_gpu, self.DETECTOR_W, self.DETECTOR_H)

        session = self.model_manager.get_session('hand_detector')
        det_outputs = session.run(['Identity', 'Identity_1'], {'input_1': preprocessed})
        regressors = det_outputs[0][0]      # shape [2016, 18]
        classificators = det_outputs[1][0]  # shape [2016, 1]

        bboxes = self._decode_detections(regressors, classificators, frame_w, frame_h)
        bboxes = bboxes[:self.MAX_HANDS]

        results = []
        for bbox in bboxes:
            roi_arr, crop_bbox = Preprocessor.crop_roi_nhwc(
                frame_gpu, bbox, self.LANDMARK_W, self.LANDMARK_H,
                frame_w=frame_w, frame_h=frame_h
            )

            lm_session = self.model_manager.get_session('hand_landmarks')
            lm_outputs = lm_session.run(['Identity', 'Identity_1', 'Identity_2'], {'input_1': roi_arr})
            landmarks_raw_flat = lm_outputs[0]               # shape [1, 63]
            handedness_score = float(lm_outputs[1][0, 0])    # scalar
            presence_score   = float(lm_outputs[2][0, 0])    # scalar

            if presence_score < self.CONF_THRESHOLD:
                continue

            landmarks_raw = landmarks_raw_flat.reshape(21, 3)
            landmarks = Preprocessor.to_image_space(
                landmarks_raw, self.LANDMARK_W, self.LANDMARK_H,
                crop_bbox, frame_w, frame_h, mirror
            )

            handedness = 'Right' if handedness_score > 0.5 else 'Left'

            results.append(HandResult(
                bbox=bbox,
                landmarks=landmarks,
                handedness=handedness,
                handedness_score=handedness_score
            ))
        return results

    def _decode_detections(self, regressors, classificators, frame_w: int, frame_h: int) -> List[BoundingBox]:
        anchors = self._anchors
        x_centers = anchors[:, 0]
        y_centers = anchors[:, 1]

        # Decode: offset / input_size + anchor_center (all normalized), then scale to pixels
        cx_norm = regressors[:, 0] / self.DETECTOR_W + x_centers
        cy_norm = regressors[:, 1] / self.DETECTOR_H + y_centers
        cx_px = cx_norm * frame_w
        cy_px = cy_norm * frame_h
        w_px  = regressors[:, 2] / self.DETECTOR_W * frame_w
        h_px  = regressors[:, 3] / self.DETECTOR_H * frame_h

        xmin = cx_px - w_px / 2
        ymin = cy_px - h_px / 2
        xmax = cx_px + w_px / 2
        ymax = cy_px + h_px / 2

        boxes = np.column_stack([xmin, ymin, xmax, ymax, classificators.flatten()])
        boxes = boxes[boxes[:, 4] > self.CONF_THRESHOLD]

        if len(boxes) == 0:
            return []

        boxes = boxes[boxes[:, 4].argsort()[::-1]]
        keep = self._nms(boxes)
        return [
            BoundingBox(
                x=float(box[0]), y=float(box[1]),
                w=float(box[2] - box[0]), h=float(box[3] - box[1]),
                confidence=float(box[4])
            )
            for box in boxes[keep]
        ]

    def _nms(self, boxes: np.ndarray) -> List[int]:
        """Vectorized non-maximum suppression."""
        keep = []
        x1 = boxes[:, 0]
        y1 = boxes[:, 1]
        x2 = boxes[:, 2]
        y2 = boxes[:, 3]
        areas = (x2 - x1) * (y2 - y1)
        order = np.arange(len(boxes))

        while order.size > 0:
            i = order[0]
            keep.append(i)
            rest = order[1:]
            if rest.size == 0:
                break
            xx1 = np.maximum(x1[i], x1[rest])
            yy1 = np.maximum(y1[i], y1[rest])
            xx2 = np.minimum(x2[i], x2[rest])
            yy2 = np.minimum(y2[i], y2[rest])
            w = np.maximum(0.0, xx2 - xx1)
            h = np.maximum(0.0, yy2 - yy1)
            inter = w * h
            ovr = inter / (areas[i] + areas[rest] - inter)
            inds = np.where(ovr <= self.NMS_IOU_THRESHOLD)[0]
            order = rest[inds]

        return keep
