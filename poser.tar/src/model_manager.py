import sys
from pathlib import Path
from typing import Dict, List
import onnxruntime as ort

class ModelManager:
    face_detector = "face_detector"
    face_landmarks = "face_landmarks"
    face_blendshapes = "face_blendshapes"
    hand_detector = "hand_detector"
    hand_landmarks = "hand_landmarks"
    pose_landmarks = "pose_landmarks"

    _MODEL_FILES = {
        face_detector: "face_detector_opset15.onnx",
        face_landmarks: "face_landmarks_detector_opset15.onnx",
        face_blendshapes: "face_blendshapes_opset15.onnx",
        hand_detector: "hand_detector_opset15.onnx",
        hand_landmarks: "hand_landmarks_detector_opset15.onnx",
        pose_landmarks: "pose_landmarks_detector_opset15.onnx"
    }

    def __init__(self, models_dir: Path) -> None:
        self.models_dir = models_dir
        self._sessions: Dict[str, ort.InferenceSession] = {}

    def validate(self, required: List[str]) -> None:
        missing_files = []
        for name in required:
            if name not in self._MODEL_FILES:
                continue
            model_path = self.models_dir / self._MODEL_FILES[name]
            if not model_path.exists():
                missing_files.append(str(model_path))
        if missing_files:
            raise FileNotFoundError(f"Missing model files: {', '.join(missing_files)}")

    def get_session(self, name: str) -> ort.InferenceSession:
        if name in self._sessions:
            return self._sessions[name]

        model_path = self.models_dir / self._MODEL_FILES[name]
        sess_options = ort.SessionOptions()
        sess_options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        sess_options.enable_mem_pattern = True
        sess_options.intra_op_num_threads = 1

        cuda_provider_opts = {
            'arena_extend_strategy': 'kNextPowerOfTwo',
            'gpu_mem_limit': 2 * 1024 ** 3,
            'cudnn_conv_algo_search': 'EXHAUSTIVE',
            'do_copy_in_default_stream': True,
        }
        providers = ['CPUExecutionProvider']
        if 'CUDAExecutionProvider' in ort.get_available_providers():
            providers = [('CUDAExecutionProvider', cuda_provider_opts), 'CPUExecutionProvider']
        else:
            print(f"Warning: CUDAExecutionProvider not available, using CPUExecutionProvider only", file=sys.stderr)

        session = ort.InferenceSession(str(model_path), sess_options=sess_options, providers=providers)
        self._sessions[name] = session
        return session
