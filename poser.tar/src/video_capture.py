from __future__ import annotations

import cv2

class VideoCaptureModule:
    """GPU-resident video capture module for pose detection applications."""

    def __init__(self, config: 'Config') -> None:
        self._cap = cv2.VideoCapture(config.camera)
        if not self._cap.isOpened():
            raise RuntimeError(f"Failed to open camera with index {config.camera}")

        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, config.width)
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, config.height)
        self.mirror = config.mirror
        self._gpu_frame = cv2.cuda_GpuMat()

    def read_frame(self) -> cv2.cuda_GpuMat:
        ret, frame = self._cap.read()
        if not ret:
            raise RuntimeError('Camera read failed')

        self._gpu_frame.upload(frame)
        if self.mirror:
            cv2.cuda.flip(self._gpu_frame, 1, self._gpu_frame)
        return self._gpu_frame

    def release(self) -> None:
        self._cap.release()
