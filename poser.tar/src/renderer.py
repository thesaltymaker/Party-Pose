from __future__ import annotations
import cv2
import numpy as np
from typing import List, Optional
from src.types import BoundingBox, Landmark, FaceResult, HandResult, BodyResult
from src.topology import FACE_CONNECTIONS, HAND_CONNECTIONS, BODY_CONNECTIONS

COLOR_FACE_LM     = (0, 255, 0)    # Green
COLOR_FACE_ROI    = (255, 255, 0)  # Cyan
COLOR_HAND_LEFT   = (0, 255, 255)  # Yellow
COLOR_HAND_RIGHT  = (0, 165, 255)  # Orange
COLOR_HAND_ROI    = (0, 200, 200)  # Muted yellow
COLOR_BODY_LM     = (255, 0, 0)    # Blue
COLOR_BODY_SKEL   = (200, 50, 50)  # Dark blue
COLOR_FPS        = (0, 255, 0)    # Green

class Renderer:
    """Renderer: draws pose detection results onto a CPU numpy frame (single download per loop)."""

    def __init__(self, show_roi: bool = False):
        self.show_roi = show_roi

    def draw_faces(self, cpu_frame: np.ndarray, results: List[FaceResult], frame_w: int, frame_h: int) -> None:
        for result in results:
            for lm in result.landmarks:
                x, y = int(lm.x), int(lm.y)
                if not (-0.05 * frame_w <= x <= 1.05 * frame_w and -0.05 * frame_h <= y <= 1.05 * frame_h):
                    continue
                cv2.circle(cpu_frame, (x, y), 2, COLOR_FACE_LM, -1)
            for conn in FACE_CONNECTIONS:
                start = result.landmarks[conn[0]]
                end   = result.landmarks[conn[1]]
                sx, sy = int(start.x), int(start.y)
                ex, ey = int(end.x),   int(end.y)
                if (-0.05 * frame_w <= sx <= 1.05 * frame_w and -0.05 * frame_h <= sy <= 1.05 * frame_h and
                        -0.05 * frame_w <= ex <= 1.05 * frame_w and -0.05 * frame_h <= ey <= 1.05 * frame_h):
                    cv2.line(cpu_frame, (sx, sy), (ex, ey), COLOR_FACE_LM, 1)
            if self.show_roi:
                bbox = result.bbox
                cv2.rectangle(cpu_frame,
                              (int(bbox.x), int(bbox.y)),
                              (int(bbox.x + bbox.w), int(bbox.y + bbox.h)),
                              COLOR_FACE_ROI, 2)

    def draw_hands(self, cpu_frame: np.ndarray, results: List[HandResult], frame_w: int, frame_h: int) -> None:
        for result in results:
            color = COLOR_HAND_LEFT if result.handedness == 'Left' else COLOR_HAND_RIGHT
            for lm in result.landmarks:
                x, y = int(lm.x), int(lm.y)
                if not (-0.05 * frame_w <= x <= 1.05 * frame_w and -0.05 * frame_h <= y <= 1.05 * frame_h):
                    continue
                cv2.circle(cpu_frame, (x, y), 3, color, -1)
            for conn in HAND_CONNECTIONS:
                start = result.landmarks[conn[0]]
                end   = result.landmarks[conn[1]]
                sx, sy = int(start.x), int(start.y)
                ex, ey = int(end.x),   int(end.y)
                if (-0.05 * frame_w <= sx <= 1.05 * frame_w and -0.05 * frame_h <= sy <= 1.05 * frame_h and
                        -0.05 * frame_w <= ex <= 1.05 * frame_w and -0.05 * frame_h <= ey <= 1.05 * frame_h):
                    cv2.line(cpu_frame, (sx, sy), (ex, ey), color, 2)
            if self.show_roi:
                bbox = result.bbox
                cv2.rectangle(cpu_frame,
                              (int(bbox.x), int(bbox.y)),
                              (int(bbox.x + bbox.w), int(bbox.y + bbox.h)),
                              COLOR_HAND_ROI, 2)

    def draw_body(self, cpu_frame: np.ndarray, result: Optional[BodyResult], frame_w: int, frame_h: int) -> None:
        if result is None:
            return
        for lm in result.landmarks[:33]:
            x, y = int(lm.x), int(lm.y)
            if not (-0.05 * frame_w <= x <= 1.05 * frame_w and -0.05 * frame_h <= y <= 1.05 * frame_h):
                continue
            if lm.presence < 0.5:
                continue
            if lm.visibility < 0.5:
                pt_color = tuple(int(c * 0.3) for c in COLOR_BODY_LM)
            else:
                pt_color = COLOR_BODY_LM
            cv2.circle(cpu_frame, (x, y), 4, pt_color, -1)
        for conn in BODY_CONNECTIONS:
            start = result.landmarks[conn[0]]
            end   = result.landmarks[conn[1]]
            if start.presence < 0.5 or end.presence < 0.5:
                continue
            sx, sy = int(start.x), int(start.y)
            ex, ey = int(end.x),   int(end.y)
            if (-0.05 * frame_w <= sx <= 1.05 * frame_w and -0.05 * frame_h <= sy <= 1.05 * frame_h and
                    -0.05 * frame_w <= ex <= 1.05 * frame_w and -0.05 * frame_h <= ey <= 1.05 * frame_h):
                cv2.line(cpu_frame, (sx, sy), (ex, ey), COLOR_BODY_SKEL, 2)

    def draw_fps(self, cpu_frame: np.ndarray, fps: float) -> None:
        cv2.putText(cpu_frame, f'FPS: {fps:.1f}', (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.0, COLOR_FPS, 2)
