from __future__ import annotations
import cv2
import numpy as np
from typing import List, Tuple
from src.types import BoundingBox, Landmark

class Preprocessor:
    """Stateless preprocessor for GPU-resident pose detection pipeline."""

    @staticmethod
    def full_frame_nhwc(frame_gpu: cv2.cuda_GpuMat, target_w: int, target_h: int) -> np.ndarray:
        rgb_gpu = cv2.cuda.cvtColor(frame_gpu, cv2.COLOR_BGR2RGB)
        resized_gpu = cv2.cuda.resize(rgb_gpu, (target_w, target_h))
        arr = resized_gpu.download()
        arr = arr.astype(np.float32) / 255.0
        arr = np.expand_dims(arr, axis=0)
        return arr

    @staticmethod
    def crop_roi_nhwc(
        frame_gpu: cv2.cuda_GpuMat,
        bbox: BoundingBox,
        target_w: int,
        target_h: int,
        pad_fraction: float = 0.25,
        frame_w: int = 0,
        frame_h: int = 0,
    ) -> Tuple[np.ndarray, BoundingBox]:
        pad_x = bbox.w * pad_fraction
        pad_y = bbox.h * pad_fraction
        crop_x = max(0, bbox.x - pad_x)
        crop_y = max(0, bbox.y - pad_y)
        crop_w = min(frame_w - crop_x, bbox.w + 2 * pad_x)
        crop_h = min(frame_h - crop_y, bbox.h + 2 * pad_y)

        roi_gpu = frame_gpu[int(crop_y):int(crop_y + crop_h), int(crop_x):int(crop_x + crop_w)]
        rgb_gpu = cv2.cuda.cvtColor(roi_gpu, cv2.COLOR_BGR2RGB)
        resized_gpu = cv2.cuda.resize(rgb_gpu, (target_w, target_h))
        arr = resized_gpu.download()
        arr = arr.astype(np.float32) / 255.0
        arr = np.expand_dims(arr, axis=0)

        actual_bbox = BoundingBox(
            x=crop_x,
            y=crop_y,
            w=crop_w,
            h=crop_h,
            confidence=bbox.confidence
        )
        return (arr, actual_bbox)

    @staticmethod
    def to_image_space(
        lms_model: np.ndarray,
        model_w: int,
        model_h: int,
        crop_bbox: BoundingBox,
        frame_w: int,
        frame_h: int,
        mirror: bool = False,
    ) -> List[Landmark]:
        landmarks = []
        for i in range(lms_model.shape[0]):
            x_norm = lms_model[i, 0] / model_w
            y_norm = lms_model[i, 1] / model_h
            x_image = crop_bbox.x + x_norm * crop_bbox.w
            y_image = crop_bbox.y + y_norm * crop_bbox.h
            z = lms_model[i, 2] if lms_model.shape[1] >= 3 else 0.0
            visibility = lms_model[i, 3] if lms_model.shape[1] >= 4 else 1.0
            presence = lms_model[i, 4] if lms_model.shape[1] >= 5 else 1.0

            if mirror:
                x_image = frame_w - x_image

            landmarks.append(
                Landmark(
                    x=x_image,
                    y=y_image,
                    z=z,
                    visibility=visibility,
                    presence=presence
                )
            )
        return landmarks
