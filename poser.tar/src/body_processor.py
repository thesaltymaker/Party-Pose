from __future__ import annotations
import numpy as np
from typing import Optional
from src.types import BoundingBox, Landmark, BodyResult
from src.model_manager import ModelManager
from src.preprocessor import Preprocessor

class BodyProcessor:
    """Processes frames for body pose detection using a GPU-resident model."""

    INPUT_W = 256
    INPUT_H = 256
    PRESENCE_THRESHOLD = 0.5
    VISIBILITY_THRESHOLD = 0.5

    def __init__(self, model_manager: ModelManager):
        self.model_manager = model_manager

    def process(self, frame_gpu, frame_w: int, frame_h: int, mirror: bool) -> Optional[BodyResult]:
        # Preprocess full frame
        arr = Preprocessor.full_frame_nhwc(frame_gpu, self.INPUT_W, self.INPUT_H)

        # Get session and run inference
        session = self.model_manager.get_session('pose_landmarks')
        outputs = session.run(['Identity', 'Identity_1'], {'input_1': arr})

        # Check body presence
        body_presence = float(outputs[1][0, 0])
        if body_presence < self.PRESENCE_THRESHOLD:
            return None

        # Reshape landmarks and create full-frame bbox
        lms = outputs[0].reshape(39, 5)
        full_frame_bbox = BoundingBox(x=0, y=0, w=frame_w, h=frame_h, confidence=body_presence)

        # Convert landmarks to image space
        landmarks = Preprocessor.to_image_space(
            lms, self.INPUT_W, self.INPUT_H, full_frame_bbox, frame_w, frame_h, mirror
        )

        return BodyResult(landmarks=landmarks, presence=body_presence)
