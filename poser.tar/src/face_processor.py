from __future__ import annotations
import numpy as np
import cv2
from typing import List, Optional
from src.types import BoundingBox, Landmark, FaceResult
from src.model_manager import ModelManager
from src.preprocessor import Preprocessor
from src.topology import CANONICAL_BLENDSHAPE_INDICES

class FaceProcessor:
    """FaceProcessor handles GPU-resident face detection, landmark extraction, and optional blendshape estimation."""

    DETECTOR_W = 128
    DETECTOR_H = 128
    LANDMARK_W = 256
    LANDMARK_H = 256
    CONF_THRESHOLD = 0.5
    NMS_IOU_THRESHOLD = 0.3

    def __init__(self, model_manager: ModelManager, enable_blendshapes: bool = False):
        self.model_manager = model_manager
        self.enable_blendshapes = enable_blendshapes
        self._anchors = self._generate_anchors()

    def _generate_anchors(self) -> np.ndarray:
        anchors = []
        # Layer 1: stride=8, 2 anchors per cell
        g = 128 // 8
        for r in range(g):
            for c in range(g):
                cx = (c + 0.5) / g
                cy = (r + 0.5) / g
                anchors.append([cx, cy])
                anchors.append([cx, cy])
        # Layer 2: stride=16, 6 anchors per cell
        g = 128 // 16
        for r in range(g):
            for c in range(g):
                cx = (c + 0.5) / g
                cy = (r + 0.5) / g
                for _ in range(6):
                    anchors.append([cx, cy])
        return np.array(anchors, dtype=np.float32)

    def process(self, frame_gpu, frame_w: int, frame_h: int, mirror: bool) -> List[FaceResult]:
        # Preprocess full frame
        arr = Preprocessor.full_frame_nhwc(frame_gpu, self.DETECTOR_W, self.DETECTOR_H)

        session = self.model_manager.get_session('face_detector')
        regressors, classificators = session.run(['regressors', 'classificators'], {'input': arr})

        bboxes = self._decode_detections(regressors[0], classificators[0], frame_w, frame_h)

        results = []
        for bbox in bboxes:
            roi_arr, crop_bbox = Preprocessor.crop_roi_nhwc(
                frame_gpu, bbox, self.LANDMARK_W, self.LANDMARK_H, frame_w=frame_w, frame_h=frame_h
            )

            session = self.model_manager.get_session('face_landmarks')
            landmarks_raw = session.run(['Identity'], {'input_12': roi_arr})[0]
            landmarks_raw = landmarks_raw.reshape(-1, 478, 3)

            landmarks = Preprocessor.to_image_space(
                landmarks_raw[0], self.LANDMARK_W, self.LANDMARK_H,
                crop_bbox, frame_w, frame_h, mirror
            )

            blendshapes = None
            if self.enable_blendshapes and landmarks_raw.size > 0:
                blendshapes = self._run_blendshapes(landmarks_raw[0])

            results.append(FaceResult(
                bbox=bbox,
                landmarks=landmarks,
                blendshapes=blendshapes
            ))

        return results

    def _decode_detections(self, regressors, classificators, frame_w, frame_h) -> List[BoundingBox]:
        confidence = 1 / (1 + np.exp(-classificators[:, 0]))
        detections = []

        for i in range(len(confidence)):
            if confidence[i] < self.CONF_THRESHOLD:
                continue

            cx = regressors[i, 0] / self.DETECTOR_W + self._anchors[i, 0]
            cy = regressors[i, 1] / self.DETECTOR_H + self._anchors[i, 1]
            w = regressors[i, 2] / self.DETECTOR_W * frame_w
            h = regressors[i, 3] / self.DETECTOR_H * frame_h

            x = cx * frame_w - w / 2
            y = cy * frame_h - h / 2

            detections.append(BoundingBox(x, y, w, h, confidence[i]))

        detections = sorted(detections, key=lambda d: d.confidence, reverse=True)
        keep = []
        while detections:
            current = detections.pop(0)
            keep.append(current)
            for i in range(len(detections) - 1, -1, -1):
                if self._iou(current, detections[i]) > self.NMS_IOU_THRESHOLD:
                    del detections[i]
        return keep

    def _iou(self, box1: BoundingBox, box2: BoundingBox) -> float:
        x1 = max(box1.x, box2.x)
        y1 = max(box1.y, box2.y)
        x2 = min(box1.x + box1.w, box2.x + box2.w)
        y2 = min(box1.y + box1.h, box2.y + box2.h)

        if x2 <= x1 or y2 <= y1:
            return 0.0

        intersection = (x2 - x1) * (y2 - y1)
        area1 = box1.w * box1.h
        area2 = box2.w * box2.h
        union = area1 + area2 - intersection

        return intersection / union

    def _run_blendshapes(self, landmarks_raw: np.ndarray) -> Optional[np.ndarray]:
        if not CANONICAL_BLENDSHAPE_INDICES:
            return None

        subset = landmarks_raw[CANONICAL_BLENDSHAPE_INDICES, :2] / 256.0
        subset = np.expand_dims(subset, axis=0)

        session = self.model_manager.get_session('face_blendshapes')
        blendshapes = session.run(['StatefulPartitionedCall:0'], {'serving_default_input_points:0': subset})[0]

        return blendshapes[0] if blendshapes.size > 0 else None
