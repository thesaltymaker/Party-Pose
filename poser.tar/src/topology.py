from typing import List, Tuple

# Hand skeleton connections (21 landmarks)
HAND_CONNECTIONS: List[Tuple[int, int]] = [
    (0, 1), (1, 2), (2, 3), (3, 4),        # Thumb
    (0, 5), (5, 6), (6, 7), (7, 8),         # Index finger
    (0, 9), (9, 10), (10, 11), (11, 12),    # Middle finger
    (0, 13), (13, 14), (14, 15), (15, 16),  # Ring finger
    (0, 17), (17, 18), (18, 19), (19, 20),  # Pinky
    (5, 9), (9, 13), (13, 17),              # Palm connections
]

# Body skeleton connections (indices 0-32 only)
BODY_CONNECTIONS: List[Tuple[int, int]] = [
    (0, 1), (1, 2), (2, 3), (3, 7),          # Face right
    (0, 4), (4, 5), (5, 6), (6, 8),          # Face left
    (9, 10),                                  # Mouth
    (11, 12), (11, 13), (13, 15), (12, 14), (14, 16),  # Shoulders/elbows/wrists
    (11, 23), (12, 24), (23, 24),             # Hips
    (15, 17), (15, 19), (15, 21), (17, 19),  # Left wrist/hand
    (16, 18), (16, 20), (16, 22), (18, 20),  # Right wrist/hand
    (23, 25), (25, 27), (27, 29), (29, 31), (27, 31),  # Left leg
    (24, 26), (26, 28), (28, 30), (30, 32), (28, 32),  # Right leg
]

# MediaPipe FaceMesh connections (478 landmarks)
# FIXME: Stub — correct topology edges needed (see FIXES_NEEDED.md)
FACE_CONNECTIONS: List[Tuple[int, int]] = []

# 146 canonical face landmark indices for blendshapes model input
# FIXME: Stub — correct 146-element index list needed (see FIXES_NEEDED.md)
CANONICAL_BLENDSHAPE_INDICES: List[int] = []
