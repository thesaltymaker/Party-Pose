# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What This Project Is

**Poser** is a real-time pose detection application for webcam video using GPU-resident processing via ONNX Runtime and OpenCV CUDA. It detects face, hand, and body landmarks using MediaPipe ONNX models and overlays them on the video feed with configurable display options.

## Running the Application

```bash
# Activate virtual environment first
source env/bin/activate

# Run the main app
python poser.py [flags]

# Run the CrewAI development orchestration (generates code via LLM agents)
python poser_crew.py
```

**CLI flags for poser.py:**
```
--mirror           Flip frame horizontally for natural interaction
--no-face          Disable face detection
--no-body          Disable body pose detection
--no-hands         Disable hand detection
--show-roi         Show Region of Interest bounding boxes
--fps              Display FPS counter overlay
--face-expressions Enable face blendshapes (52 expression coefficients)
--camera 0         Camera device index (default: 0)
--width 1280       Frame width (default: 1280)
--height 720       Frame height (default: 720)
```

There is no test suite, linter config, or build system. The project is purely runtime Python.

## Architecture

### GPU-Resident Processing Pipeline

The core design principle is that frames are uploaded to GPU memory once and never downloaded until final display:

```
Webcam → GPU Upload → Detector (full frame, fast) → Landmark Model (ROI crop only) → Overlay → Display
         └─────────────────────────────────────── cv2.cuda.GpuMat throughout ──────────────────┘
```

### Two-Stage Detection

Each modality uses a cheap detector on the full frame, then an expensive landmark model runs only on the small detected ROI:

- **Face**: `face_detector` → `face_landmarks_detector` → `face_blendshapes` (optional)
- **Hands**: `hand_detector` → `hand_landmarks_detector`
- **Body**: `pose_landmarks_detector` (single-stage; no separate detector needed)

### Model Files (`/models/`)

| File | Input | Output |
|------|-------|--------|
| `face_detector_opset15.onnx` | `[1, 3, H, W]` | `[N, 6]` (x,y,w,h,conf,class) |
| `face_landmarks_detector_opset15.onnx` | `[1, 3, 192, 192]` | `[1, 468, 3]` (x,y,z) |
| `face_blendshapes_opset15.onnx` | face landmarks | `[1, 52]` expression coefficients |
| `hand_detector_opset15.onnx` | `[1, 3, H, W]` | `[N, 6]` |
| `hand_landmarks_detector_opset15.onnx` | `[1, 3, 224, 224]` | `[1, 21, 3]` per hand |
| `pose_landmarks_detector_opset15.onnx` | `[1, 3, 256, 256]` | `[1, 33, 5]` (x,y,z,visibility,presence) |

Landmark counts: 468 face, 21 per hand, 33 body.

### ONNX Runtime Configuration

Always use `CUDAExecutionProvider` as the first provider:
```python
import onnxruntime as ort
session = ort.InferenceSession(model_path, providers=["CUDAExecutionProvider", "CPUExecutionProvider"])
```

Pre-allocate inference buffers per model to avoid per-frame allocation overhead.

### Key Source Locations

- **Generated working implementations**: `output_successful_run/poser_app.py`, `output_successful_run/optimized_pose_detection.py`
- **Modular refactor attempt**: `output_run_d/src/` (video_capture.py, cuda_utils.py, etc.)
- **Specification**: `poser_spec.md` — authoritative source for requirements
- **Architecture design**: `architecture.md`

### CrewAI Development Orchestration

`poser_crew.py` runs a hierarchical multi-agent system (Manager, Software Architect, Senior Python Developer, CUDA Specialist, QA Engineer) using local Ollama LLMs to generate and refine the application code. It writes output to versioned `output_*/` directories. LLM backends: Ollama at localhost, SearXNG at `http://192.168.2.59:8082` for search.

## Performance Targets

- >30 FPS on RTX 3060, >60 FPS on RTX 5080
- GPU memory <4 GB on RTX 3060
- CPU usage <20% during operation
- Detector inference <5ms, landmark inference <10ms per ROI

## Out of Scope

No data persistence, recording, web interface, REST API, multi-camera support, gesture recognition beyond landmarks, network streaming, or config files (CLI only).
